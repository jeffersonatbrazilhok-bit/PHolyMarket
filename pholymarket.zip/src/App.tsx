/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Wallet, 
  Search, 
  TrendingUp, 
  Users, 
  CreditCard, 
  TrainFront, 
  Gavel, 
  Sun, 
  Theater, 
  CloudCheck,
  Share2,
  HelpCircle,
  X,
  ArrowRight,
  Clock,
  AlertCircle,
  QrCode,
  History,
  Briefcase,
  Trophy,
  Leaf,
  Tv,
  ChevronLeft,
  LogOut,
  CheckCircle2,
  Shield,
  Zap,
  Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Market {
  id: string;
  title: string;
  category: string;
  volume: string;
  yesPrice: number;
  noPrice: number;
  icon: React.ReactNode;
  image?: string;
  description: string;
  endDate: string;
  priceChange?: 'up' | 'down' | null;
}

const FEATURED_MARKET: Market = {
  id: 'featured-1',
  title: '2028 Philippine Presidential Election Winner',
  category: 'Politics',
  volume: '₱245M',
  yesPrice: 53,
  noPrice: 53, // House edge
  icon: <Gavel className="w-5 h-5 text-ph-gold" />,
  description: "As the 2028 elections approach, the political landscape is shifting. Will the current administration's coalition hold, or will a new opposition force emerge? Key figures like Sara Duterte and Martin Romualdez are under intense scrutiny.",
  endDate: '2028-05-08T23:59:59',
  image: 'https://picsum.photos/seed/ph-election-2028/1200/800'
};

const MARKETS: Market[] = [
  {
    id: 'icc-1',
    title: 'Will the ICC issue an arrest warrant for a high-ranking PH official by Dec 2026?',
    category: 'Politics',
    volume: '₱85.2M',
    yesPrice: 42,
    noPrice: 64,
    icon: <Gavel className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/justice-court/800/400',
    description: "The International Criminal Court's investigation into the previous administration's drug war continues. Legal experts are divided on the timing of potential warrants.",
    endDate: '2026-12-31T23:59:59',
  },
  {
    id: 'pbb-12',
    title: 'Will a "Housemate from Mindanao" win PBB Season 12?',
    category: 'Entertainment',
    volume: '₱18.5M',
    yesPrice: 38,
    noPrice: 68,
    icon: <Tv className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/pbb-house/800/400',
    description: "PBB Season 12 is heating up. Regional voting blocks often play a huge role in determining the Big Winner.",
    endDate: '2026-07-15T23:59:59',
  },
  {
    id: 'mlbb-m7',
    title: 'Will a PH Team win the M7 World Championship?',
    category: 'Entertainment',
    volume: '₱42.1M',
    yesPrice: 75,
    noPrice: 31,
    icon: <CloudCheck className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/mlbb-m7/800/400',
    description: "The Philippines has dominated MLBB esports for years. Can the local teams defend their title against rising powerhouses from Indonesia and Malaysia?",
    endDate: '2026-12-20T23:59:59',
  },
  {
    id: 'pba-gov-2026',
    title: 'Will Barangay Ginebra win the 2026 PBA Governors\' Cup?',
    category: 'Sports',
    volume: '₱35.7M',
    yesPrice: 48,
    noPrice: 58,
    icon: <Trophy className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/ginebra-fans/800/400',
    description: "The crowd favorites are looking for another title. With a healthy roster, Ginebra is always a top contender in the import-laden conference.",
    endDate: '2026-05-30T23:59:59',
  },
  {
    id: 'peso-60',
    title: 'Will the USD/PHP exchange rate hit ₱60.00 by end of 2026?',
    category: 'Economy',
    volume: '₱92.4M',
    yesPrice: 28,
    noPrice: 78,
    icon: <TrendingUp className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/currency-exchange/800/400',
    description: "Global economic pressures and local inflation are weighing on the Peso. Analysts are watching the BSP's next moves closely.",
    endDate: '2026-12-31T23:59:59',
  },
  {
    id: 'bulacan-airport',
    title: 'Will the New Manila International Airport (Bulacan) open its first runway by 2027?',
    category: 'Infrastructure',
    volume: '₱112M',
    yesPrice: 55,
    noPrice: 51,
    icon: <TrainFront className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/airport-construction/800/400',
    description: "The massive airport project in Bulacan is a key infrastructure goal. Construction progress is steady, but environmental concerns remain.",
    endDate: '2027-12-31T23:59:59',
  },
  {
    id: 'gilas-fiba-2027',
    title: 'Will Gilas Pilipinas qualify for the 2027 FIBA World Cup?',
    category: 'Sports',
    volume: '₱28.9M',
    yesPrice: 62,
    noPrice: 44,
    icon: <Trophy className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/gilas-basketball/800/400',
    description: "The road to the 2027 World Cup in Qatar starts now. Gilas needs strong performances in the qualifying windows to secure their spot.",
    endDate: '2027-02-28T23:59:59',
  },
  {
    id: 'chacha-2026',
    title: 'Will a Plebiscite for Charter Change be held in 2026?',
    category: 'Politics',
    volume: '₱54.2M',
    yesPrice: 33,
    noPrice: 73,
    icon: <Gavel className="w-5 h-5 text-ph-gold" />,
    image: 'https://picsum.photos/seed/constitution-ph/800/400',
    description: "The push for economic amendments to the Constitution is gaining momentum in Congress. Will it reach the people for a vote this year?",
    endDate: '2026-12-15T23:59:59',
  }
];

const CATEGORIES = ['All', 'Politics', 'Economy', 'Infrastructure', 'Sports', 'Environment', 'Entertainment'];

const Countdown = ({ endDate }: { endDate: string }) => {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const end = new Date(endDate).getTime();
      const diff = end - now;

      if (diff <= 0) {
        setTimeLeft('ENDED');
        clearInterval(timer);
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

      setTimeLeft(`${days}d ${hours}h ${minutes}m`);
    }, 1000);

    return () => clearInterval(timer);
  }, [endDate]);

  return (
    <div className="flex items-center gap-2 text-[10px] font-black text-ph-gold uppercase tracking-widest bg-ph-gold/10 px-3 py-1 rounded-full border border-ph-gold/20 shadow-[0_0_10px_rgba(252,209,22,0.1)]">
      <Clock className="w-3.5 h-3.5" /> {timeLeft}
    </div>
  );
};

const AuthModal = ({ isOpen, onClose, onLogin }: { isOpen: boolean, onClose: () => void, onLogin: (email: string) => void }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-ph-dark/80 backdrop-blur-md">
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="glass-card w-full max-w-md rounded-[3rem] overflow-hidden shadow-2xl border border-white/10">
        <div className="p-10">
          <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-black tracking-tighter uppercase font-display">{mode === 'login' ? 'Welcome Back' : 'Join PHolyMarket'}</h2>
            <button onClick={onClose} className="p-3 hover:bg-white/5 rounded-full transition-colors text-white/40 hover:text-white"><X className="w-6 h-6" /></button>
          </div>

          <div className="space-y-8">
            <div>
              <label className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 mb-3 block">PH Mobile Number or Email</label>
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="e.g. 09171234567 or user@email.com"
                  className="w-full bg-white/5 border-2 border-white/5 rounded-2xl px-6 py-5 text-sm font-bold focus:border-ph-gold outline-none transition-all text-white placeholder:text-white/20"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                />
                {identifier.startsWith('09') && identifier.length === 11 && (
                  <div className="absolute right-6 top-1/2 -translate-y-1/2">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  </div>
                )}
              </div>
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 mb-3 block">Password</label>
              <input 
                type="password" 
                placeholder="••••••••"
                className="w-full bg-white/5 border-2 border-white/5 rounded-2xl px-6 py-5 text-sm font-bold focus:border-ph-gold outline-none transition-all text-white placeholder:text-white/20"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button 
              onClick={() => { onLogin(identifier); onClose(); }}
              className="w-full bg-ph-gold hover:bg-ph-gold/90 text-ph-dark font-black py-5 rounded-2xl shadow-xl shadow-ph-gold/20 transition-all active:scale-95 text-lg uppercase tracking-widest"
            >
              {mode === 'login' ? 'Log In' : 'Create Account'}
            </button>

            <div className="text-center">
              <button 
                onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}
                className="text-[11px] font-black uppercase tracking-widest text-white/30 hover:text-ph-gold transition-colors"
              >
                {mode === 'login' ? "Don't have an account? Sign Up" : "Already have an account? Log In"}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const TopUpModal = ({ isOpen, onClose, onTopUp }: { isOpen: boolean, onClose: () => void, onTopUp: (amount: number) => void }) => {
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [topUpAmount, setTopUpAmount] = useState('500');
  const wallets = [
    { name: 'GCash', color: 'bg-[#007DFE]', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/52/GCash_logo.svg/1200px-GCash_logo.svg.png' },
    { name: 'Maya', color: 'bg-[#000000]', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/PayMaya_Logo.png/1200px-PayMaya_Logo.png' },
    { name: 'Coins.ph', color: 'bg-[#FFD700]', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4b/Coins.ph_logo.svg/1200px-Coins.ph_logo.svg.png' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-ph-dark/80 backdrop-blur-md" />
          <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0, y: 20 }} className="relative w-full max-w-md glass-card rounded-[3rem] p-10 shadow-2xl border border-white/10">
            <button onClick={() => selectedWallet ? setSelectedWallet(null) : onClose()} className="absolute left-8 top-8 text-white/30 hover:text-white transition-colors">
              {selectedWallet ? <ChevronLeft className="w-7 h-7" /> : <X className="w-7 h-7" />}
            </button>
            <div className="text-center mb-10">
              <h2 className="text-3xl font-black font-display uppercase tracking-tighter">{selectedWallet ? `Scan to Pay` : 'Top up Wallet'}</h2>
              <p className="text-white/40 text-xs font-bold tracking-widest uppercase mt-2">Select your preferred method</p>
            </div>
            
            {!selectedWallet ? (
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 mb-3 block">Amount to Top up</label>
                  <div className="grid grid-cols-3 gap-3">
                    {['500', '1000', '5000'].map(amt => (
                      <button key={amt} onClick={() => setTopUpAmount(amt)} className={`py-3 rounded-2xl text-xs font-black border transition-all ${topUpAmount === amt ? 'bg-ph-gold text-ph-dark border-ph-gold shadow-lg shadow-ph-gold/20' : 'bg-white/5 text-white/40 border-white/10 hover:border-ph-gold/50'}`}>₱{amt}</button>
                    ))}
                  </div>
                </div>
                <div className="space-y-3">
                  {wallets.map(wallet => (
                    <button key={wallet.name} onClick={() => setSelectedWallet(wallet.name)} className="w-full flex items-center justify-between p-5 rounded-[1.5rem] bg-white/5 border border-white/10 hover:border-ph-gold transition-all group">
                      <div className="flex items-center gap-5">
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center p-2 shadow-sm overflow-hidden">
                          <img src={wallet.logo} alt={wallet.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                        </div>
                        <span className="font-black text-base uppercase tracking-widest">{wallet.name}</span>
                      </div>
                      <ArrowRight className="w-5 h-5 text-white/20 group-hover:text-ph-gold transition-all" />
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center py-4">
                <div className="bg-white p-6 rounded-[2rem] shadow-2xl mb-8 border border-white/10">
                  <QrCode className="w-48 h-48 text-ph-dark" />
                </div>
                <p className="text-xs text-white/40 text-center mb-8 uppercase tracking-[0.2em] font-black leading-relaxed">Scan this QR code with your <span className="text-ph-gold">{selectedWallet}</span> app to complete the transaction</p>
                
                <div className="w-full bg-white/5 p-6 rounded-2xl border border-white/10 mb-8">
                  <div className="text-[10px] font-black uppercase tracking-[0.3em] text-ph-gold mb-2">Linked Account</div>
                  <div className="text-lg font-black font-display">0917 **** 567</div>
                </div>

                <button onClick={() => { onTopUp(parseFloat(topUpAmount)); onClose(); setSelectedWallet(null); }} className="w-full py-5 bg-ph-gold text-ph-dark rounded-2xl font-black shadow-xl shadow-ph-gold/20 uppercase tracking-widest hover:bg-ph-gold/90 transition-all active:scale-95">I've sent the payment</button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const BetModal = ({ isOpen, onClose, market, side, onPlaceBet, balance }: { isOpen: boolean, onClose: () => void, market: Market | null, side: 'YES' | 'NO' | null, onPlaceBet: (amount: number, shares: number) => void, balance: number }) => {
  const [amount, setAmount] = useState('');
  const [isConfirmed, setIsConfirmed] = useState(false);
  const price = side === 'YES' ? market?.yesPrice : market?.noPrice;
  
  const possibleWin = useMemo(() => {
    if (!amount || !price) return 0;
    return parseFloat(amount) / (price / 100);
  }, [amount, price]);

  const isInsufficient = useMemo(() => {
    return amount ? parseFloat(amount) > balance : false;
  }, [amount, balance]);

  useEffect(() => {
    if (!isOpen) {
      setIsConfirmed(false);
      setAmount('');
    }
  }, [isOpen]);

  const handleConfirm = () => {
    onPlaceBet(parseFloat(amount), possibleWin);
    setIsConfirmed(true);
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  return (
    <AnimatePresence>
      {isOpen && market && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="absolute inset-0 bg-ph-dark/80 backdrop-blur-md" />
          <motion.div initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0, y: 20 }} className="relative w-full max-w-md glass-card rounded-[3rem] p-10 shadow-2xl border border-white/10 max-h-[90vh] overflow-y-auto">
            <button onClick={onClose} className="absolute right-8 top-8 text-white/30 hover:text-white transition-colors z-10"><X className="w-7 h-7" /></button>
            
            {!isConfirmed ? (
              <>
                <div className="mb-10">
                  {market.image && (
                    <div className="-mx-10 -mt-10 mb-8 h-48 overflow-hidden rounded-t-[3rem] relative">
                      <img src={market.image} alt={market.title} className="w-full h-full object-cover grayscale-[20%]" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-gradient-to-t from-ph-dark via-ph-dark/20 to-transparent" />
                    </div>
                  )}
                  <span className={`inline-block px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-4 shadow-lg ${side === 'YES' ? 'bg-emerald-500 text-ph-dark' : 'bg-ph-red text-white'}`}>Betting {side}</span>
                  <h2 className="text-2xl font-black leading-tight mb-6 font-display">{market.title}</h2>
                  <div className="bg-white/5 p-6 rounded-2xl text-sm text-white/60 leading-relaxed border border-white/10 italic">
                    "{market.description}"
                  </div>
                </div>
                <div className="bg-white/5 rounded-3xl p-8 border border-white/10 mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <label className="text-[10px] font-black uppercase text-white/30 tracking-[0.3em]">Enter Amount (₱)</label>
                    {isInsufficient && <span className="text-[10px] font-black text-ph-red uppercase tracking-widest flex items-center gap-1"><AlertCircle className="w-3 h-3" /> Insufficient</span>}
                  </div>
                  <input type="number" placeholder="0.00" className={`w-full bg-transparent border-none p-0 text-5xl font-black focus:ring-0 placeholder:text-white/10 font-display ${isInsufficient ? 'text-ph-red' : 'text-white'}`} value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus />
                  <div className="flex gap-2 mt-6">
                    {[100, 500, 1000, 5000].map(val => (
                      <button key={val} onClick={() => setAmount(val.toString())} className="flex-1 py-2.5 rounded-xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest hover:border-ph-gold hover:text-ph-gold transition-all">₱{val}</button>
                    ))}
                  </div>
                </div>
                <div className="space-y-4 mb-10">
                  <div className="flex justify-between text-sm"><span className="text-white/30 font-bold uppercase tracking-widest text-[10px]">Price per share</span><span className="font-black text-ph-gold">₱{price?.toFixed(2)}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-white/30 font-bold uppercase tracking-widest text-[10px]">Possible Win</span><span className="font-black text-emerald-400">₱{possibleWin.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></div>
                  <div className="flex justify-between text-sm pt-4 border-t border-white/5"><span className="text-white/30 font-bold uppercase tracking-widest text-[10px]">ROI</span><span className="font-black text-emerald-400">+{amount ? (((possibleWin - parseFloat(amount)) / parseFloat(amount)) * 100).toFixed(1) : '0.0'}%</span></div>
                </div>
                <button onClick={handleConfirm} disabled={!amount || parseFloat(amount) <= 0 || isInsufficient} className={`w-full py-5 rounded-2xl font-black text-lg uppercase tracking-[0.2em] transition-all shadow-2xl active:scale-95 ${side === 'YES' ? 'bg-emerald-500 hover:bg-emerald-400 text-ph-dark shadow-emerald-500/20 disabled:bg-emerald-500/20 disabled:text-emerald-500/40' : 'bg-ph-red hover:bg-ph-red/80 text-white shadow-ph-red/20 disabled:bg-ph-red/20 disabled:text-ph-red/40'}`}>Confirm {side} Bet</button>
              </>
            ) : (
              <div className="py-16 text-center">
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="w-24 h-24 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-8 border border-emerald-500/30 shadow-[0_0_30px_rgba(16,185,129,0.2)]">
                  <CheckCircle2 className="w-12 h-12" />
                </motion.div>
                <h2 className="text-3xl font-black mb-4 uppercase tracking-tighter font-display">Bet Placed!</h2>
                <p className="text-white/40 text-sm font-bold tracking-widest uppercase">Your prediction has been recorded. Good luck!</p>
                <div className="mt-10 glass-card p-8 rounded-3xl border border-white/10 text-left w-full">
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-[10px] font-black uppercase tracking-widest text-white/20">Amount Bet</div>
                    <div className="text-xl font-black text-ph-gold">₱{parseFloat(amount).toLocaleString()}</div>
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="text-[10px] font-black uppercase tracking-widest text-white/20">Potential Payout</div>
                    <div className="text-xl font-black text-emerald-400">₱{possibleWin.toLocaleString()}</div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

interface UserHolding {
  marketId: string;
  marketTitle: string;
  side: 'YES' | 'NO';
  shares: number;
  avgPrice: number;
  currentPrice: number;
}

interface BetHistory {
  id: string;
  marketTitle: string;
  side: 'YES' | 'NO';
  amount: number;
  shares: number;
  price: number;
  type: 'BUY' | 'SELL';
  timestamp: string;
  status: 'OPEN' | 'RESOLVED';
  pnl?: number;
}

const MOCK_HOLDINGS: UserHolding[] = [
  {
    marketId: 'icc-1',
    marketTitle: 'Will the ICC issue an arrest warrant for a high-ranking PH official by Dec 2026?',
    side: 'YES',
    shares: 250,
    avgPrice: 38,
    currentPrice: 42
  },
  {
    marketId: 'mlbb-m7',
    marketTitle: 'Will a PH Team win the M7 World Championship?',
    side: 'YES',
    shares: 500,
    avgPrice: 65,
    currentPrice: 75
  }
];

const MOCK_HISTORY: BetHistory[] = [
  {
    id: 'tx-1',
    marketTitle: 'Will a PH Team win the M7 World Championship?',
    side: 'YES',
    amount: 325,
    shares: 500,
    price: 65,
    type: 'BUY',
    timestamp: '2026-02-20T14:30:00',
    status: 'OPEN'
  },
  {
    id: 'tx-2',
    marketTitle: 'Will the ICC issue an arrest warrant...',
    side: 'YES',
    amount: 95,
    shares: 250,
    price: 38,
    type: 'BUY',
    timestamp: '2026-02-19T09:15:00',
    status: 'OPEN'
  },
  {
    id: 'tx-3',
    marketTitle: 'Will 2024 be the hottest year on record in PH?',
    side: 'YES',
    amount: 500,
    shares: 568,
    price: 88,
    type: 'BUY',
    timestamp: '2024-11-10T10:00:00',
    status: 'RESOLVED',
    pnl: 68
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'Markets' | 'Portfolio'>('Markets');
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem('isLoggedIn') === 'true');
  const [userEmail, setUserEmail] = useState(() => localStorage.getItem('userEmail') || '');
  
  const [balance, setBalance] = useState(() => parseFloat(localStorage.getItem('balance') || '12450'));
  const [userHoldings, setUserHoldings] = useState<UserHolding[]>(() => JSON.parse(localStorage.getItem('userHoldings') || JSON.stringify(MOCK_HOLDINGS)));
  const [userHistory, setUserHistory] = useState<BetHistory[]>(() => JSON.parse(localStorage.getItem('userHistory') || JSON.stringify(MOCK_HISTORY)));
  
  const [markets, setMarkets] = useState<Market[]>(MARKETS);
  const [featuredMarket, setFeaturedMarket] = useState<Market>(MARKETS[0]);
  const [bettingMarket, setBettingMarket] = useState<Market | null>(null);
  const [bettingSide, setBettingSide] = useState<'YES' | 'NO' | null>(null);
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  useEffect(() => {
    localStorage.setItem('isLoggedIn', isLoggedIn.toString());
    localStorage.setItem('userEmail', userEmail);
    localStorage.setItem('balance', balance.toString());
    localStorage.setItem('userHoldings', JSON.stringify(userHoldings));
    localStorage.setItem('userHistory', JSON.stringify(userHistory));
  }, [isLoggedIn, userEmail, balance, userHoldings, userHistory]);

  const handleTopUp = (amount: number) => {
    setBalance(prev => prev + amount);
    setToast({ message: `Successfully topped up ₱${amount.toLocaleString()}`, type: 'success' });
  };

  const handlePlaceBet = (amount: number, shares: number) => {
    if (!bettingMarket || !bettingSide) return;
    
    if (amount > balance) {
      setToast({ message: 'Insufficient balance', type: 'error' });
      return;
    }

    setBalance(prev => prev - amount);
    setToast({ message: 'Bet placed successfully!', type: 'success' });
    
    const newHolding: UserHolding = {
      marketId: bettingMarket.id,
      marketTitle: bettingMarket.title,
      side: bettingSide,
      shares: shares,
      avgPrice: bettingSide === 'YES' ? bettingMarket.yesPrice : bettingMarket.noPrice,
      currentPrice: bettingSide === 'YES' ? bettingMarket.yesPrice : bettingMarket.noPrice
    };

    setUserHoldings(prev => {
      const existing = prev.find(h => h.marketId === bettingMarket.id && h.side === bettingSide);
      if (existing) {
        return prev.map(h => h === existing ? {
          ...h,
          shares: h.shares + shares,
          avgPrice: (h.avgPrice * h.shares + newHolding.avgPrice * shares) / (h.shares + shares)
        } : h);
      }
      return [newHolding, ...prev];
    });

    const newTx: BetHistory = {
      id: `tx-${Date.now()}`,
      marketTitle: bettingMarket.title,
      side: bettingSide,
      amount: amount,
      shares: shares,
      price: newHolding.avgPrice,
      type: 'BUY',
      timestamp: new Date().toISOString(),
      status: 'OPEN'
    };

    setUserHistory(prev => [newTx, ...prev]);

    // Simulate price impact
    setMarkets(prev => prev.map(m => {
      if (m.id === bettingMarket.id) {
        const impact = bettingSide === 'YES' ? 1 : -1;
        const newYes = Math.max(1, Math.min(99, m.yesPrice + impact));
        return { ...m, yesPrice: newYes, noPrice: 104 - newYes };
      }
      return m;
    }));
  };

  const handleSell = (holding: UserHolding) => {
    const proceeds = holding.shares * (holding.currentPrice / 100);
    setBalance(prev => prev + proceeds);
    setToast({ message: `Sold shares for ₱${proceeds.toLocaleString()}`, type: 'success' });
    
    setUserHoldings(prev => prev.filter(h => h !== holding));
    
    const newTx: BetHistory = {
      id: `tx-${Date.now()}`,
      marketTitle: holding.marketTitle,
      side: holding.side,
      amount: proceeds,
      shares: holding.shares,
      price: holding.currentPrice,
      type: 'SELL',
      timestamp: new Date().toISOString(),
      status: 'RESOLVED',
      pnl: proceeds - (holding.shares * (holding.avgPrice / 100))
    };

    setUserHistory(prev => [newTx, ...prev]);
  };

  const totalPortfolioValue = useMemo(() => {
    const holdingsValue = userHoldings.reduce((acc, h) => acc + (h.shares * (h.currentPrice / 100)), 0);
    return balance + holdingsValue;
  }, [balance, userHoldings]);

  const totalEarnings = useMemo(() => {
    return userHistory.reduce((acc, tx) => acc + (tx.pnl || 0), 0);
  }, [userHistory]);

  useEffect(() => {
    const interval = setInterval(() => {
      setMarkets(prevMarkets => prevMarkets.map(m => {
        if (Math.random() > 0.3) return { ...m, priceChange: null };
        const change = Math.random() > 0.5 ? 1 : -1;
        const newYesPrice = Math.max(1, Math.min(99, m.yesPrice + change));

        return {
          ...m,
          yesPrice: newYesPrice,
          noPrice: 104 - newYesPrice, // House edge: sum to 104
          priceChange: change > 0 ? 'up' : 'down'
        };
      }));

      setFeaturedMarket(prev => {
        if (Math.random() > 0.5) return { ...prev, priceChange: null };
        const change = Math.random() > 0.5 ? 1 : -1;
        const newYesPrice = Math.max(1, Math.min(99, prev.yesPrice + change));
        return {
          ...prev,
          yesPrice: newYesPrice,
          noPrice: 104 - newYesPrice, // House edge: sum to 104
          priceChange: change > 0 ? 'up' : 'down'
        };
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const filteredMarkets = useMemo(() => 
    markets.filter(m => (activeCategory === 'All' || m.category === activeCategory) && m.title.toLowerCase().includes(searchQuery.toLowerCase())),
    [markets, activeCategory, searchQuery]
  );

  return (
    <div className="min-h-screen bg-ph-dark text-white font-sans selection:bg-ph-gold selection:text-ph-dark">
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} onLogin={(email) => { setUserEmail(email); setIsLoggedIn(true); }} />
      <TopUpModal isOpen={isTopUpOpen} onClose={() => setIsTopUpOpen(false)} onTopUp={handleTopUp} />
      <BetModal isOpen={!!bettingMarket} onClose={() => setBettingMarket(null)} market={bettingMarket} side={bettingSide} onPlaceBet={handlePlaceBet} balance={balance} />

      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50, x: '-50%' }} 
            animate={{ opacity: 1, y: 0, x: '-50%' }} 
            exit={{ opacity: 0, y: 50, x: '-50%' }} 
            className={`fixed bottom-8 left-1/2 z-[200] px-6 py-3 rounded-2xl shadow-2xl font-black text-sm flex items-center gap-3 border ${toast.type === 'success' ? 'bg-emerald-500 text-white border-emerald-400' : 'bg-ph-red text-white border-ph-red/50'}`}
          >
            {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
            {toast.message}
          </motion.div>
        )}
      </AnimatePresence>

      <header className="sticky top-0 z-50 border-b border-white/5 bg-ph-dark/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-10">
            <a href="#" className="flex items-center gap-4 group">
              <div className="relative">
                <div className="w-14 h-14 bg-gradient-to-br from-ph-blue via-ph-dark to-ph-red rounded-2xl shadow-[0_0_30px_rgba(0,56,168,0.3)] border border-white/20 flex items-center justify-center overflow-hidden group-hover:scale-105 transition-all duration-500 relative">
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
                  <svg viewBox="0 0 100 100" className="w-10 h-10 relative z-10 drop-shadow-[0_0_8px_rgba(252,209,22,0.8)]">
                    <path d="M15 25 L85 25 L85 50 L15 50 Z" fill="#0038A8" />
                    <path d="M15 50 L85 50 L85 75 L15 75 Z" fill="#CE1126" />
                    <path d="M15 25 L50 50 L15 75 Z" fill="white" />
                    <circle cx="28" cy="50" r="7" fill="#FCD116" className="animate-pulse" />
                    <path d="M45 45 L65 35 L85 45" fill="none" stroke="ph-gold" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="opacity-90" />
                  </svg>
                  <div className="absolute inset-0 border-2 border-ph-gold/30 rounded-2xl pointer-events-none" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-4 border-ph-dark z-10 shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
              </div>
              <div className="flex flex-col">
                <h1 className="text-3xl font-black tracking-tighter leading-none flex items-center font-display">
                  <span className="text-white">PH</span>
                  <span className="text-ph-gold italic gold-glow">oly</span>
                  <span className="text-ph-red">Market</span>
                </h1>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-[0.4em] text-ph-gold/60">Predict • Bet • Win</span>
                </div>
              </div>
            </a>
            <nav className="hidden md:flex items-center gap-8">
              {['Markets', 'Portfolio'].map(tab => (
                <button key={tab} onClick={() => setActiveTab(tab as any)} className={`text-xs font-black uppercase tracking-[0.2em] transition-all relative py-2 ${activeTab === tab ? 'text-ph-gold gold-glow' : 'text-white/40 hover:text-white'}`}>
                  {tab}
                  {activeTab === tab && <motion.div layoutId="activeTab" className="absolute -bottom-1 left-0 right-0 h-0.5 bg-ph-gold shadow-[0_0_10px_#FCD116]" />}
                </button>
              ))}
            </nav>
          </div>
          <div className="flex-1 max-w-md mx-4 hidden lg:block">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20 group-focus-within:text-ph-gold transition-colors" />
              <input type="text" placeholder="Search markets..." className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 py-3 text-sm font-bold focus:ring-2 focus:ring-ph-gold/20 focus:border-ph-gold/50 outline-none transition-all placeholder:text-white/10" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
            </div>
          </div>
          <div className="flex items-center gap-6">
            {isLoggedIn ? (
              <>
                <div className="hidden sm:flex flex-col items-end">
                  <span className="text-[10px] font-black uppercase text-white/30 tracking-widest">Balance</span>
                  <span className="text-lg font-black text-ph-gold gold-glow">₱{balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <button onClick={() => setIsTopUpOpen(true)} className="bg-ph-blue hover:bg-ph-blue/80 text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-[0_0_20px_rgba(0,56,168,0.3)] flex items-center gap-2 active:scale-95 border border-white/10">
                  <Wallet className="w-4 h-4" /> Top up
                </button>
                <div className="relative group/profile">
                  <div className="w-12 h-12 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-center font-black text-ph-gold cursor-pointer hover:border-ph-gold transition-all shadow-xl">
                    {userEmail.charAt(0).toUpperCase() || 'U'}
                  </div>
                  <div className="absolute right-0 top-full mt-3 w-56 bg-ph-dark/95 backdrop-blur-2xl rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] border border-white/10 py-3 opacity-0 invisible group-hover/profile:opacity-100 group-hover/profile:visible transition-all z-50">
                    <div className="px-4 py-2 border-b border-white/5 mb-2">
                      <div className="text-[10px] font-black text-white/30 uppercase tracking-widest">Logged in as</div>
                      <div className="text-xs font-bold truncate">{userEmail}</div>
                    </div>
                    <button onClick={() => setActiveTab('Portfolio')} className="w-full text-left px-4 py-3 text-xs font-black uppercase tracking-widest hover:bg-white/5 flex items-center gap-3 transition-colors">
                      <Briefcase className="w-4 h-4 text-ph-gold" /> My Portfolio
                    </button>
                    <button onClick={() => { setIsLoggedIn(false); setUserEmail(''); }} className="w-full text-left px-4 py-3 text-xs font-black uppercase tracking-widest text-ph-red hover:bg-ph-red/10 flex items-center gap-3 transition-colors">
                      <LogOut className="w-4 h-4" /> Sign Out
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <button 
                onClick={() => setIsAuthOpen(true)}
                className="bg-ph-gold text-ph-dark px-8 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(252,209,22,0.3)]"
              >
                Log In / Sign Up
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {activeTab === 'Markets' ? (
          <>
            <div className="flex items-center gap-3 mb-10 overflow-x-auto pb-4 no-scrollbar">
              {CATEGORIES.map(cat => (
                <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all whitespace-nowrap border ${activeCategory === cat ? 'bg-ph-gold text-ph-dark border-ph-gold shadow-[0_0_15px_rgba(252,209,22,0.3)]' : 'bg-white/5 text-white/40 border-white/10 hover:border-ph-gold/50 hover:text-white'}`}>{cat}</button>
              ))}
            </div>

            <section className="mb-16">
              <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="relative group overflow-hidden rounded-[2.5rem] bg-ph-dark border border-white/10 grid md:grid-cols-2 shadow-2xl shadow-black/50 min-h-[500px]">
                <div className="absolute inset-0 bg-gradient-to-br from-ph-blue/20 via-transparent to-ph-red/20 opacity-50" />
                <div className="p-10 md:p-16 flex flex-col justify-center relative z-10">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <span className="bg-ph-gold text-ph-dark text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full shadow-[0_0_10px_rgba(252,209,22,0.5)]">Featured</span>
                      <span className="text-white/40 text-xs font-bold tracking-widest">₱135M Vol</span>
                      {featuredMarket.priceChange && (
                        <motion.span initial={{ opacity: 0, x: -5 }} animate={{ opacity: 1, x: 0 }} key={Date.now()} className={`text-[10px] font-black uppercase flex items-center gap-1 ${featuredMarket.priceChange === 'up' ? 'text-emerald-400' : 'text-ph-red'}`}>
                          {featuredMarket.priceChange === 'up' ? '▲' : '▼'} Live
                        </motion.span>
                      )}
                    </div>
                    <Countdown endDate={featuredMarket.endDate} />
                  </div>
                  <h2 className="text-4xl md:text-6xl font-black mb-8 leading-[1.1] tracking-tighter font-display">{featuredMarket.title}</h2>
                  <p className="text-white/60 mb-10 text-sm md:text-lg leading-relaxed max-w-xl">{featuredMarket.description}</p>
                  <div className="flex items-center gap-6">
                    <button onClick={() => { setBettingMarket(featuredMarket); setBettingSide('YES'); }} className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-ph-dark font-black py-5 rounded-3xl text-xl transition-all shadow-lg shadow-emerald-500/20 active:scale-95 relative overflow-hidden group/btn">
                      <span className="relative z-10">YES {featuredMarket.yesPrice}%</span>
                      <div className="absolute inset-0 bg-white/20 translate-y-full group-hover/btn:translate-y-0 transition-transform duration-300" />
                    </button>
                    <button onClick={() => { setBettingMarket(featuredMarket); setBettingSide('NO'); }} className="flex-1 bg-ph-red hover:bg-ph-red/80 text-white font-black py-5 rounded-3xl text-xl transition-all shadow-lg shadow-ph-red/20 active:scale-95 relative overflow-hidden group/btn">
                      <span className="relative z-10">NO {featuredMarket.noPrice}%</span>
                      <div className="absolute inset-0 bg-white/10 translate-y-full group-hover/btn:translate-y-0 transition-transform duration-300" />
                    </button>
                  </div>
                </div>
                <div className="relative h-full min-h-[300px] md:min-h-full">
                  <img src={featuredMarket.image} alt={featuredMarket.title} className="absolute inset-0 w-full h-full object-cover grayscale-[20%] group-hover:scale-105 transition-transform duration-[2s]" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-r from-ph-dark via-ph-dark/20 to-transparent" />
                  <div className="absolute inset-0 bg-gradient-to-t from-ph-dark via-transparent to-transparent" />
                </div>
              </motion.div>
            </section>

            <div className="flex items-center justify-between mb-8">
              <h3 className="text-2xl font-black tracking-tighter uppercase flex items-center gap-3 font-display">
                <TrendingUp className="text-ph-gold w-6 h-6" /> Trending Markets
              </h3>
              <div className="text-xs font-bold text-white/30 tracking-widest uppercase">Updated 1m ago</div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {filteredMarkets.map((market, idx) => (
                <motion.div 
                  key={market.id} 
                  initial={{ opacity: 0, y: 20 }} 
                  animate={{ opacity: 1, y: 0 }} 
                  transition={{ delay: idx * 0.05 }}
                  className="glass-card rounded-[2rem] overflow-hidden group hover:border-ph-gold/30 transition-all duration-500 flex flex-col h-full"
                >
                  <div className="relative h-44 overflow-hidden">
                    <img src={market.image} alt={market.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 grayscale-[30%] group-hover:grayscale-0" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 bg-gradient-to-t from-ph-dark/90 to-transparent" />
                    <div className="absolute top-4 left-4 bg-ph-dark/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-2">
                      {market.icon}
                      <span className="text-[10px] font-black uppercase tracking-widest text-white/80">{market.category}</span>
                    </div>
                    {market.priceChange && (
                      <div className={`absolute top-4 right-4 px-2 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest flex items-center gap-1 shadow-xl ${market.priceChange === 'up' ? 'bg-emerald-500 text-white' : 'bg-ph-red text-white'}`}>
                        {market.priceChange === 'up' ? '▲' : '▼'} {market.priceChange}
                      </div>
                    )}
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <div className="flex items-center justify-between mb-4">
                      <Countdown endDate={market.endDate} />
                      <div className="text-right">
                        <div className="text-[8px] font-black uppercase text-white/30 tracking-widest">Volume</div>
                        <div className="text-xs font-black text-ph-gold">₱{market.volume}</div>
                      </div>
                    </div>
                    <h4 className="text-sm md:text-base font-black mb-4 leading-snug group-hover:text-ph-gold transition-colors line-clamp-2 min-h-[3rem] font-display">{market.title}</h4>
                    <p className="text-[11px] text-white/40 mb-6 line-clamp-2 leading-relaxed flex-1">{market.description}</p>
                    <div className="grid grid-cols-2 gap-3 mt-auto">
                      <button onClick={() => { setBettingMarket(market); setBettingSide('YES'); }} className={`font-black py-3 rounded-2xl text-xs transition-all border relative overflow-hidden ${market.priceChange === 'up' ? 'bg-emerald-500 text-ph-dark border-emerald-500' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500 hover:text-ph-dark'}`}>
                        YES {market.yesPrice}%
                        {market.priceChange === 'up' && <motion.div initial={{ top: '100%' }} animate={{ top: '-100%' }} className="absolute inset-0 bg-white/20 pointer-events-none" />}
                      </button>
                      <button onClick={() => { setBettingMarket(market); setBettingSide('NO'); }} className={`font-black py-3 rounded-2xl text-xs transition-all border relative overflow-hidden ${market.priceChange === 'down' ? 'bg-ph-red text-white border-ph-red' : 'bg-ph-red/10 text-ph-red border-ph-red/20 hover:bg-ph-red hover:text-white'}`}>
                        NO {market.noPrice}%
                        {market.priceChange === 'down' && <motion.div initial={{ top: '100%' }} animate={{ top: '-100%' }} className="absolute inset-0 bg-white/10 pointer-events-none" />}
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <div className="bg-gradient-to-br from-ph-blue to-ph-dark rounded-[2.5rem] p-10 text-white shadow-2xl shadow-ph-blue/20 relative overflow-hidden group border border-white/10">
                <div className="relative z-10">
                  <div className="text-[10px] font-black uppercase tracking-[0.3em] text-ph-gold mb-3">Total Portfolio Value</div>
                  <div className="text-5xl font-black mb-6 font-display gold-glow">₱{totalPortfolioValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                  <div className="flex items-center gap-2 text-xs font-bold bg-white/10 w-fit px-4 py-1.5 rounded-full backdrop-blur-md border border-white/10">
                    <TrendingUp className="w-4 h-4 text-ph-gold" /> +12.4% this week
                  </div>
                </div>
                <div className="absolute -right-12 -bottom-12 opacity-5 group-hover:scale-110 transition-transform duration-1000 rotate-12">
                  <Briefcase className="w-64 h-64" />
                </div>
              </div>
              <div className="glass-card rounded-[2.5rem] p-10">
                <div className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 mb-3">Total Earnings</div>
                <div className={`text-5xl font-black mb-6 font-display ${totalEarnings >= 0 ? 'text-emerald-400' : 'text-ph-red'}`}>
                  {totalEarnings >= 0 ? '+' : ''}₱{totalEarnings.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
                <div className="text-xs font-bold text-white/20 tracking-widest uppercase">All-time profit/loss</div>
              </div>
              <div className="glass-card rounded-[2.5rem] p-10">
                <div className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 mb-3">Available Balance</div>
                <div className="text-5xl font-black mb-6 font-display text-ph-gold gold-glow">₱{balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                <button onClick={() => setIsTopUpOpen(true)} className="text-xs font-black uppercase tracking-widest text-ph-gold hover:text-white flex items-center gap-2 transition-colors">
                  Top up now <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-16">
              <section>
                <h3 className="text-2xl font-black mb-8 flex items-center gap-3 uppercase tracking-tighter font-display">
                  <Wallet className="text-ph-gold w-7 h-7" /> Payment Methods
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="glass-card rounded-3xl p-8 flex items-center justify-between group hover:border-ph-gold/50 transition-all">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center overflow-hidden border border-white/10">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/GCash_logo.svg/1200px-GCash_logo.svg.png" alt="GCash" className="w-10 h-10 object-contain" />
                      </div>
                      <div>
                        <div className="font-black text-lg">GCash</div>
                        <div className="text-xs font-bold text-white/20 tracking-widest">0917 **** 567</div>
                      </div>
                    </div>
                    <button className="text-xs font-black uppercase tracking-widest text-ph-gold hover:text-white transition-colors">Edit</button>
                  </div>
                  <div className="glass-card rounded-3xl p-8 flex items-center justify-between group hover:border-ph-gold/50 transition-all">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center overflow-hidden border border-white/10">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Maya_logo.svg/1200px-Maya_logo.svg.png" alt="Maya" className="w-10 h-10 object-contain" />
                      </div>
                      <div>
                        <div className="font-black text-lg">Maya</div>
                        <div className="text-xs font-bold text-white/20 tracking-widest">Not Linked</div>
                      </div>
                    </div>
                    <button className="text-xs font-black uppercase tracking-widest text-ph-gold hover:text-white transition-colors">Link Now</button>
                  </div>
                </div>
              </section>

              <section>
                <h3 className="text-2xl font-black mb-8 flex items-center gap-3 uppercase tracking-tighter font-display">
                  <Briefcase className="text-ph-gold w-7 h-7" /> Active Holdings
                </h3>
                
                <div className="glass-card rounded-[2.5rem] overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-white/5 bg-white/5">
                          <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Market</th>
                          <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Side</th>
                          <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Shares</th>
                          <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Avg Price</th>
                          <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Current</th>
                          <th className="px-8 py-5 text-[10px] font-black uppercase tracking-[0.3em] text-white/30 text-right">P/L</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {userHoldings.map((h) => {
                          const pl = h.shares * ((h.currentPrice - h.avgPrice) / 100);
                          const plPercent = ((h.currentPrice - h.avgPrice) / h.avgPrice) * 100;
                          return (
                            <tr key={h.marketId} className="hover:bg-white/5 transition-colors group cursor-pointer">
                              <td className="px-8 py-8">
                                <div className="font-black text-sm group-hover:text-ph-gold transition-colors max-w-xs truncate">{h.marketTitle}</div>
                              </td>
                              <td className="px-8 py-8">
                                <span className={`px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest ${h.side === 'YES' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-ph-red/10 text-ph-red'}`}>{h.side}</span>
                              </td>
                              <td className="px-8 py-8 font-bold text-sm">{h.shares}</td>
                              <td className="px-8 py-8 font-bold text-sm text-white/30">₱{h.avgPrice}</td>
                              <td className="px-8 py-8 font-bold text-sm">₱{h.currentPrice}</td>
                              <td className="px-8 py-8 text-right">
                                <div className="flex flex-col items-end gap-3">
                                  <div className={`font-black text-sm ${pl >= 0 ? 'text-emerald-400' : 'text-ph-red'}`}>
                                    {pl >= 0 ? '+' : ''}₱{pl.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                  </div>
                                  <button onClick={() => handleSell(h)} className="px-4 py-1.5 bg-white/5 hover:bg-ph-gold hover:text-ph-dark rounded-xl text-[9px] font-black uppercase tracking-widest transition-all border border-white/10">Sell Shares</button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </section>

              <section>
                <h3 className="text-2xl font-black mb-8 flex items-center gap-3 uppercase tracking-tighter font-display">
                  <History className="text-ph-gold w-7 h-7" /> Recent Activity
                </h3>
                <div className="space-y-6">
                  {userHistory.map((tx) => (
                    <motion.div key={tx.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="glass-card rounded-3xl p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 group hover:border-ph-gold/30 transition-all">
                      <div className="flex items-center gap-6">
                        <div className={`p-4 rounded-2xl ${tx.type === 'BUY' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-ph-blue/10 text-ph-blue'}`}>
                          {tx.type === 'BUY' ? <ArrowRight className="w-6 h-6 rotate-[-45deg]" /> : <ArrowRight className="w-6 h-6 rotate-[135deg]" />}
                        </div>
                        <div>
                          <h4 className="font-black text-base mb-2 group-hover:text-ph-gold transition-colors font-display">{tx.marketTitle}</h4>
                          <div className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest text-white/20">
                            <span>{new Date(tx.timestamp).toLocaleDateString()}</span>
                            <span className="w-1.5 h-1.5 bg-white/10 rounded-full" />
                            <span className={tx.side === 'YES' ? 'text-emerald-400' : 'text-ph-red'}>{tx.side}</span>
                            <span className="w-1.5 h-1.5 bg-white/10 rounded-full" />
                            <span>{tx.shares} Shares @ ₱{tx.price}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-10 justify-between md:justify-end">
                        <div className="text-right">
                          <div className="text-[10px] font-black uppercase text-white/20 mb-1 tracking-widest">Amount</div>
                          <div className="font-black text-lg">₱{tx.amount.toLocaleString()}</div>
                        </div>
                        {tx.status === 'RESOLVED' && (
                          <div className="text-right">
                            <div className="text-[10px] font-black uppercase text-white/20 mb-1 tracking-widest">P/L</div>
                            <div className={`font-black text-lg ${tx.pnl && tx.pnl > 0 ? 'text-emerald-400' : 'text-ph-red'}`}>
                              {tx.pnl && tx.pnl > 0 ? '+' : ''}₱{tx.pnl?.toLocaleString()}
                            </div>
                          </div>
                        )}
                        <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${tx.status === 'OPEN' ? 'bg-ph-blue/20 text-ph-blue border border-ph-blue/30' : 'bg-white/5 text-white/20 border border-white/10'}`}>
                          {tx.status}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </div>
          </>
        )}

        <footer className="mt-20 py-12 border-t border-white/5 text-white/20 text-[10px] uppercase font-black tracking-[0.4em] text-center">
          <div className="flex items-center justify-center gap-4 mb-6">
            <div className="w-8 h-8 bg-ph-blue/20 rounded-lg flex items-center justify-center border border-ph-blue/30">
              <Shield className="w-4 h-4 text-ph-blue" />
            </div>
            <div className="w-8 h-8 bg-ph-gold/20 rounded-lg flex items-center justify-center border border-ph-gold/30">
              <Zap className="w-4 h-4 text-ph-gold" />
            </div>
            <div className="w-8 h-8 bg-ph-red/20 rounded-lg flex items-center justify-center border border-ph-red/30">
              <Lock className="w-4 h-4 text-ph-red" />
            </div>
          </div>
          © 2024 PHolyMarket - Decentralized Prediction Platform for the Philippines
        </footer>
      </main>
    </div>
  );
}
